/**
 * Gameday Board proxy: a Cloudflare Worker (works on the free plan).
 *
 * What it does: the website asks this Worker for sports data, the Worker fetches
 * it from ESPN, MLB or Sleeper on the server side, and sends it back with the header that
 * lets a browser read it (CORS).
 *
 * What it refuses: everything except the few scoreboard, standings and stat
 * addresses listed below. It is not a general-purpose proxy.
 *
 * How the site calls it:
 *   https://YOUR-WORKER.workers.dev/?url=https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard
 */

// OPTIONAL: only let your own website use this proxy from a browser.
// Leave the list empty to allow any website. Add your site's address once it is published.
const ALLOWED_ORIGINS = [
  // 'https://your-site.pages.dev',
];

// The only addresses this proxy will fetch. `ttl` is how many seconds an answer is reused.
const LEAGUES = '(football/nfl|baseball/mlb|basketball/nba)';
const ALLOWED = [
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/scoreboard$'), ttl: 4 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/scoreboard$'), ttl: 4 },
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/v2/sports/' + LEAGUES + '/standings$'),       ttl: 300 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/v2/sports/' + LEAGUES + '/standings$'),       ttl: 300 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/standings$/,                                        ttl: 300 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/schedule$/,                                         ttl: 60 },
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v3/sports/' + LEAGUES + '/leaders$'),    ttl: 600 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/stats\/leaders$/,                                    ttl: 600 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/schedule\/postseason\/series$/,                          ttl: 30 },
  // one MLB game's play list (pitch by pitch), read to catch ABS challenges between scoreboard refreshes
  { host: 'sports.core.api.espn.com', path: /^\/v2\/sports\/baseball\/leagues\/mlb\/events\/\d{1,12}\/competitions\/\d{1,12}\/plays$/, ttl: 5 },
  // one game's details: box score and win probability
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/summary$'),     ttl: 8 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/summary$'),     ttl: 8 },
  // NFL player stats for one week (the page adds the weeks up for its live stat leaders)
  { host: 'api.sleeper.app',       path: /^\/stats\/nfl\/20\d\d\/(1?\d)$/,                                 ttl: 30 },
  { host: 'api.sleeper.com',       path: /^\/stats\/nfl\/20\d\d\/(1?\d)$/,                                 ttl: 30 },
];

// The only query settings that are passed along. Anything else is dropped.
const ALLOWED_PARAMS = ['dates', 'limit', 'week', 'seasontype', 'season', 'level', 'leagueId', 'standingsTypes', 'sportId', 'startDate', 'endDate', 'leaderCategories', 'statGroup', 'leaderGameTypes', 'season_type', 'position[]', 'order_by', 'event', 'page'];
const SAFE_VALUE = /^[A-Za-z0-9,_-]{1,160}$/;

const memory = new Map(); // address -> { at, body }, kept while this Worker instance stays warm

function corsHeaders(origin) {
  const headers = {
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Accept, Content-Type',
    'Access-Control-Expose-Headers': 'X-Proxy, X-Proxy-Error, X-Proxy-Cache, X-Upstream-Status',
    'Access-Control-Max-Age': '86400',
    'X-Proxy': 'gameday-board',
  };
  if (!ALLOWED_ORIGINS.length) headers['Access-Control-Allow-Origin'] = '*';
  else {
    headers['Vary'] = 'Origin';
    if (ALLOWED_ORIGINS.includes(origin)) headers['Access-Control-Allow-Origin'] = origin;
  }
  return headers;
}

function json(status, data, headers, extra) {
  return new Response(JSON.stringify(data), {
    status,
    headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers, extra || {}),
  });
}
const refuse = (status, message, headers) => json(status, { error: message }, headers, { 'X-Proxy-Error': '1' });

export default {
  async fetch(request) {
    const origin = request.headers.get('Origin') || '';
    const cors = corsHeaders(origin);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method !== 'GET') return refuse(405, 'Only GET requests are allowed.', cors);
    if (ALLOWED_ORIGINS.length && origin && !ALLOWED_ORIGINS.includes(origin)) {
      return refuse(403, 'The website ' + origin + ' is not allowed to use this proxy.', cors);
    }

    const here = new URL(request.url);
    const wanted = here.searchParams.get('url');
    if (!wanted) {
      return json(200, {
        ok: true,
        service: 'Gameday Board proxy',
        usage: here.origin + '/?url=<a scoreboard or standings address>',
        test: here.origin + '/?url=' + encodeURIComponent('https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard'),
      }, cors);
    }

    let target;
    try { target = new URL(wanted); } catch (e) { return refuse(400, 'The url value is not a valid address.', cors); }
    const rule = target.protocol === 'https:' && !target.port && !target.username && !target.password &&
      ALLOWED.find(r => r.host === target.hostname && r.path.test(target.pathname));
    if (!rule) return refuse(403, 'That address is not on this proxy\'s allow-list.', cors);

    // Rebuild the address from approved parts only.
    const clean = new URL('https://' + rule.host + target.pathname);
    for (const name of ALLOWED_PARAMS) {
      const value = target.searchParams.get(name);
      if (value !== null && SAFE_VALUE.test(value)) clean.searchParams.set(name, value);
    }
    const address = clean.toString();

    const saved = memory.get(address);
    if (saved && Date.now() - saved.at < rule.ttl * 1000) {
      return new Response(saved.body, { status: 200, headers: Object.assign({
        'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
        'X-Proxy-Cache': 'HIT', 'X-Upstream-Status': '200' }, cors) });
    }

    let upstream, body;
    try {
      upstream = await fetch(address, {
        headers: { 'Accept': 'application/json', 'User-Agent': 'Mozilla/5.0 (compatible; GamedayBoardProxy/1.0)' },
        redirect: 'manual',
      });
      body = await upstream.text();
    } catch (e) {
      return refuse(502, 'The proxy could not reach ' + rule.host + ': ' + (e && e.message ? e.message : 'unknown error'), cors);
    }
    if (upstream.status >= 300 && upstream.status < 400) {
      return refuse(502, rule.host + ' tried to redirect the request (HTTP ' + upstream.status + '), which this proxy does not follow.', cors);
    }

    if (upstream.status === 200 && body.length < 4000000) {
      memory.set(address, { at: Date.now(), body });
      if (memory.size > 40) memory.delete(memory.keys().next().value);
    }

    // The upstream status is passed through unchanged, so the website can report the real error.
    return new Response(body, { status: upstream.status, headers: Object.assign({
      'Content-Type': upstream.headers.get('Content-Type') || 'application/json; charset=utf-8',
      'Cache-Control': 'no-store', 'X-Proxy-Cache': 'MISS', 'X-Upstream-Status': String(upstream.status) }, cors) });
  },
};

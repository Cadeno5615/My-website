// Gameday Board: optional helper for notifications. Put this file in the same folder as index.html.
// It does two things and nothing else: lets phones show the page's notifications, and brings the page
// forward when a notification is tapped. It does not cache or change any request.
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (event) { event.waitUntil(self.clients.claim()); });
self.addEventListener('notificationclick', function (event) {
  var data = event.notification.data || null;
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
    var page = list[0];
    if (page) { page.postMessage({ gameday: data }); return page.focus(); }
    return self.clients.openWindow('./');
  }));
});
